import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

const DiscoverRecipes = () => {
  const [recipes, setRecipes] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAISearching, setIsAISearching] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState(null);
  const [filters, setFilters] = useState({
    cuisine: '',
    dietaryRestrictions: [],
    maxCookingTime: ''
  });
  const [searchTimeout, setSearchTimeout] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchRecipes();
  }, []);

  const fetchRecipes = async () => {
    // Fetch all recipes logic
  };

  const handleAISearch = async (query) => {
    if (!query || query.trim().length === 0) {
      // If empty, fetch all recipes
      fetchRecipes();
      setAiSuggestions(null);
      return;
    }

    setIsAISearching(true);
    setLoading(true);
    try {
      const params = new URLSearchParams({
        query: query.trim()
      });

      // Add optional filters if they exist
      if (filters.cuisine && filters.cuisine !== '') {
        params.append('cuisine', filters.cuisine);
      }
      if (filters.dietaryRestrictions && filters.dietaryRestrictions.length > 0) {
        params.append('dietaryRestrictions', filters.dietaryRestrictions.join(','));
      }
      if (filters.maxCookingTime && filters.maxCookingTime !== '') {
        params.append('cookingTime', filters.maxCookingTime);
      }

      const token = localStorage.getItem('token');
      const response = await axios.get(
        `http://localhost:5000/api/recipes/ai-search?${params.toString()}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      console.log('✨ AI Search Response:', response.data);
      setRecipes(response.data.recipes || []);
      setAiSuggestions(response.data.aiSuggestions);
    } catch (error) {
      console.error('AI search failed:', error);
      toast.error('AI search failed, showing all recipes');
      fetchRecipes();
      setAiSuggestions(null);
    } finally {
      setIsAISearching(false);
      setLoading(false);
    }
  };

  const handleSearchChange = (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    
    // Clear previous timeout
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }
    
    // Debounce AI search
    const timeout = setTimeout(() => {
      handleAISearch(query);
    }, 800);
    
    setSearchTimeout(timeout);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setAiSuggestions(null);
    fetchRecipes();
  };

  return (
    <div className="discover-recipes">
      <div className="discover-header">
        <h1>Discover Recipes</h1>
        <div className="search-container">
          <div className="search-input-wrapper">
            <input
              type="text"
              placeholder="🤖 Try: 'vegan dinner with chickpeas' or 'quick breakfast under 20 minutes'"
              value={searchQuery}
              onChange={handleSearchChange}
              className="search-input"
            />
            {isAISearching && <span className="ai-searching">🔍 Searching...</span>}
            {searchQuery && (
              <button onClick={handleClearSearch} className="clear-search-btn">
                ✕
              </button>
            )}
          </div>
        </div>

        {aiSuggestions && (
          <div className="ai-suggestions">
            <p className="ai-reasoning">💡 {aiSuggestions.reasoning}</p>
            <div className="suggestion-tags">
              {aiSuggestions.searchKeywords?.map((keyword, idx) => (
                <span key={idx} className="suggestion-tag">{keyword}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="recipes-list">
        {recipes.map(recipe => (
          <div key={recipe._id} className="recipe-card">
            {/* Recipe card content */}
          </div>
        ))}
      </div>

      {!loading && recipes.length === 0 && (
        <div className="no-recipes">
          <p>No recipes found</p>
          {(searchQuery || Object.values(filters).some(f => f && f.length > 0)) && (
            <>
              <p>Try adjusting your search or filters</p>
              <button onClick={handleClearSearch} className="show-all-btn">
                Show All Recipes
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default DiscoverRecipes;