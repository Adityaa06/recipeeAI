import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { mealPlanService } from '../services/mealPlanService';
import { shoppingListService } from '../services/shoppingListService';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';

const MealPlanner = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [mealPlans, setMealPlans] = useState([]);
    const [loading, setLoading] = useState(true);
    const [generating, setGenerating] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState(null);

    useEffect(() => {
        loadMealPlans();
    }, []);

    const loadMealPlans = async () => {
        try {
            const data = await mealPlanService.getMealPlans();
            setMealPlans(data.mealPlans || []);
            if (data.mealPlans && data.mealPlans.length > 0) {
                setSelectedPlan(data.mealPlans[0]);
            }
        } catch (error) {
            console.error('Error loading meal plans:', error);
        } finally {
            setLoading(false);
        }
    };

    const generateAIMealPlan = async () => {
        setGenerating(true);
        try {
            const data = await mealPlanService.generateMealPlan({ days: 7 });
            await loadMealPlans();
            alert('AI meal plan generated successfully!');
        } catch (error) {
            console.error('Error generating meal plan:', error);
            alert('Error generating meal plan. Please try again.');
        } finally {
            setGenerating(false);
        }
    };

    const generateShoppingList = async (mealPlanId) => {
        try {
            await shoppingListService.generateShoppingList(mealPlanId, 'Weekly Shopping List');
            navigate('/shopping-list');
        } catch (error) {
            console.error('Error generating shopping list:', error);
            alert('Error generating shopping list. Please try again.');
        }
    };

    if (loading) {
        return (
            <div className="min-h-[calc(100vh-64px)] flex items-center justify-center">
                <LoadingSpinner size="lg" text="Loading meal plans..." />
            </div>
        );
    }

    return (
        <div className="min-h-[calc(100vh-64px)] bg-gray-50 py-8">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="font-display font-bold text-3xl text-gray-900 mb-2">
                            Meal Planner
                        </h1>
                        <p className="text-gray-600">
                            Generate AI-powered meal plans based on your preferences
                        </p>
                    </div>

                    <button
                        onClick={generateAIMealPlan}
                        disabled={generating}
                        className="btn btn-primary flex items-center gap-2"
                    >
                        {generating ? (
                            <>
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                                Generating...
                            </>
                        ) : (
                            <>
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                                </svg>
                                Generate AI Plan ✨
                            </>
                        )}
                    </button>
                </div>

                {mealPlans.length === 0 ? (
                    <div className="card p-12 text-center">
                        <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">No meal plans yet</h3>
                        <p className="text-gray-600 mb-4">
                            Generate your first AI-powered meal plan tailored to your dietary preferences
                        </p>
                        <button onClick={generateAIMealPlan} className="btn btn-primary">
                            Generate First Plan ✨
                        </button>
                    </div>
                ) : (
                    <div className="grid lg:grid-cols-4 gap-6">
                        {/* Meal Plans List */}
                        <div className="lg:col-span-1">
                            <div className="card p-4 space-y-2">
                                <h3 className="font-semibold text-sm text-gray-700 mb-2">Your Plans</h3>
                                {mealPlans.map(plan => (
                                    <button
                                        key={plan._id}
                                        onClick={() => setSelectedPlan(plan)}
                                        className={`w-full text-left p-3 rounded-lg transition ${selectedPlan?._id === plan._id
                                            ? 'bg-primary-50 border-2 border-primary-600'
                                            : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                                            }`}
                                    >
                                        <div className="font-medium text-sm mb-1">{plan.title}</div>
                                        <div className="text-xs text-gray-600">
                                            {new Date(plan.startDate).toLocaleDateString()} - {new Date(plan.endDate).toLocaleDateString()}
                                        </div>
                                        {plan.generatedByAI && (
                                            <div className="text-xs text-primary-600 mt-1">✨ AI Generated</div>
                                        )}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Selected Meal Plan */}
                        <div className="lg:col-span-3">
                            {selectedPlan && (
                                <>
                                    <div className="card p-6 mb-4">
                                        <div className="flex items-center justify-between mb-4">
                                            <h2 className="font-semibold text-2xl">{selectedPlan.title}</h2>
                                            <button
                                                onClick={() => generateShoppingList(selectedPlan._id)}
                                                className="btn btn-outline text-sm"
                                            >
                                                Generate Shopping List
                                            </button>
                                        </div>

                                        <div className="text-sm text-gray-600 mb-6">
                                            {new Date(selectedPlan.startDate).toLocaleDateString()} - {new Date(selectedPlan.endDate).toLocaleDateString()}
                                        </div>

                                        <div className="space-y-6">
                                            {selectedPlan.meals.map((meal, index) => (
                                                <div key={index} className="border-b border-gray-200 pb-6 last:border-0 last:pb-0">
                                                    <h3 className="font-semibold text-lg mb-4">{meal.day}</h3>

                                                    <div className="grid md:grid-cols-3 gap-4">
                                                        {/* Breakfast */}
                                                        <div className="bg-yellow-50 rounded-lg p-4">
                                                            <div className="font-medium text-sm text-yellow-900 mb-2">Breakfast</div>
                                                            {meal.breakfast ? (
                                                                <Link
                                                                    to={`/recipes/${meal.breakfast._id}`}
                                                                    className="text-sm text-yellow-800 hover:text-yellow-900 hover:underline font-medium block"
                                                                >
                                                                    {meal.breakfast.title}
                                                                </Link>
                                                            ) : (
                                                                <div className="text-sm text-yellow-600 italic">Not planned</div>
                                                            )}
                                                        </div>

                                                        {/* Lunch */}
                                                        <div className="bg-green-50 rounded-lg p-4">
                                                            <div className="font-medium text-sm text-green-900 mb-2">Lunch</div>
                                                            {meal.lunch ? (
                                                                <Link
                                                                    to={`/recipes/${meal.lunch._id}`}
                                                                    className="text-sm text-green-800 hover:text-green-900 hover:underline font-medium block"
                                                                >
                                                                    {meal.lunch.title}
                                                                </Link>
                                                            ) : (
                                                                <div className="text-sm text-green-600 italic">Not planned</div>
                                                            )}
                                                        </div>

                                                        {/* Dinner */}
                                                        <div className="bg-blue-50 rounded-lg p-4">
                                                            <div className="font-medium text-sm text-blue-900 mb-2">Dinner</div>
                                                            {meal.dinner ? (
                                                                <Link
                                                                    to={`/recipes/${meal.dinner._id}`}
                                                                    className="text-sm text-blue-800 hover:text-blue-900 hover:underline font-medium block"
                                                                >
                                                                    {meal.dinner.title}
                                                                </Link>
                                                            ) : (
                                                                <div className="text-sm text-blue-600 italic">Not planned</div>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MealPlanner;
