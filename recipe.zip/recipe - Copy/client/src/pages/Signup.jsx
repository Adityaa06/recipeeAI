import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Signup = () => {
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        dietaryRestrictions: [],
        allergies: [],
        cuisinePreferences: []
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const { signup } = useAuth();
    const navigate = useNavigate();

    const dietaryOptions = [
        'vegan', 'vegetarian', 'gluten-free', 'dairy-free',
        'keto', 'paleo', 'low-carb', 'halal', 'kosher'
    ];

    const cuisineOptions = [
        'italian', 'chinese', 'indian', 'mexican', 'japanese',
        'thai', 'mediterranean', 'american', 'french', 'korean'
    ];

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
        setError('');
    };

    const handleCheckboxChange = (e, field) => {
        const value = e.target.value;
        const isChecked = e.target.checked;

        setFormData(prev => ({
            ...prev,
            [field]: isChecked
                ? [...prev[field], value]
                : prev[field].filter(item => item !== value)
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (formData.password !== formData.confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        if (formData.password.length < 6) {
            setError('Password must be at least 6 characters');
            return;
        }

        setLoading(true);

        const { confirmPassword, ...signupData } = formData;
        const result = await signup(signupData);

        if (result.success) {
            navigate('/dashboard');
        } else {
            setError(result.error);
        }

        setLoading(false);
    };

    return (
        <div className="min-h-screen bg-gray-50 py-12 px-4">
            <div className="max-w-2xl mx-auto">
                <div className="text-center mb-8">
                    <h2 className="font-display font-bold text-3xl text-gray-900 mb-2">
                        Create Your Account
                    </h2>
                    <p className="text-gray-600">
                        Get started with personalized AI-powered meal planning
                    </p>
                </div>

                <div className="card p-8">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        {error && (
                            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                                {error}
                            </div>
                        )}

                        {/* Basic Info */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                                    Username
                                </label>
                                <input
                                    id="username"
                                    name="username"
                                    type="text"
                                    required
                                    value={formData.username}
                                    onChange={handleChange}
                                    className="input"
                                    placeholder="johndoe"
                                />
                            </div>

                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                                    Email Address
                                </label>
                                <input
                                    id="email"
                                    name="email"
                                    type="email"
                                    required
                                    value={formData.email}
                                    onChange={handleChange}
                                    className="input"
                                    placeholder="you@example.com"
                                />
                            </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                                    Password
                                </label>
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    required
                                    value={formData.password}
                                    onChange={handleChange}
                                    className="input"
                                    placeholder="••••••••"
                                />
                            </div>

                            <div>
                                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-2">
                                    Confirm Password
                                </label>
                                <input
                                    id="confirmPassword"
                                    name="confirmPassword"
                                    type="password"
                                    required
                                    value={formData.confirmPassword}
                                    onChange={handleChange}
                                    className="input"
                                    placeholder="••••••••"
                                />
                            </div>
                        </div>

                        {/* Dietary Restrictions */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Dietary Restrictions (Optional)
                            </label>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                {dietaryOptions.map(option => (
                                    <label key={option} className="flex items-center space-x-2 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            value={option}
                                            checked={formData.dietaryRestrictions.includes(option)}
                                            onChange={(e) => handleCheckboxChange(e, 'dietaryRestrictions')}
                                            className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                                        />
                                        <span className="text-sm text-gray-700 capitalize">{option}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        {/* Allergies */}
                        <div>
                            <label htmlFor="allergies" className="block text-sm font-medium text-gray-700 mb-2">
                                Allergies (Optional, comma-separated)
                            </label>
                            <input
                                id="allergies"
                                name="allergies"
                                type="text"
                                value={formData.allergies.join(', ')}
                                onChange={(e) => setFormData({
                                    ...formData,
                                    allergies: e.target.value.split(',').map(a => a.trim()).filter(Boolean)
                                })}
                                className="input"
                                placeholder="peanuts, shellfish"
                            />
                        </div>

                        {/* Cuisine Preferences */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Cuisine Preferences (Optional)
                            </label>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                {cuisineOptions.map(option => (
                                    <label key={option} className="flex items-center space-x-2 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            value={option}
                                            checked={formData.cuisinePreferences.includes(option)}
                                            onChange={(e) => handleCheckboxChange(e, 'cuisinePreferences')}
                                            className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                                        />
                                        <span className="text-sm text-gray-700 capitalize">{option}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="btn btn-primary w-full"
                        >
                            {loading ? 'Creating Account...' : 'Create Account'}
                        </button>
                    </form>

                    <div className="mt-6 text-center">
                        <p className="text-gray-600">
                            Already have an account?{' '}
                            <Link to="/login" className="text-primary-600 hover:text-primary-700 font-medium">
                                Log in
                            </Link>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Signup;
