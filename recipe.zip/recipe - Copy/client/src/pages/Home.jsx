import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { recipeService } from '../services/recipeService';
import RecipeCard from '../components/RecipeCard';
import LoadingSpinner from '../components/LoadingSpinner';

const Home = () => {
    const [selectedMode, setSelectedMode] = useState(null); // 'dish' or 'ingredient'
    const [query, setQuery] = useState('');
    const [recipes, setRecipes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [hasSearched, setHasSearched] = useState(false);
    const navigate = useNavigate();

    const handleModeSelect = (mode) => {
        setSelectedMode(mode);
        setQuery('');
        setRecipes([]);
        setHasSearched(false);
    };

    const handleSearch = async (e) => {
        e.preventDefault();
        if (!query.trim()) return;

        setLoading(true);
        setHasSearched(true);
        try {
            const data = await recipeService.searchRecipes(query);
            setRecipes(data.recipes || []);
        } catch (error) {
            console.error('Error searching recipes:', error);
            setRecipes([]);
        } finally {
            setLoading(false);
        }
    };

    const handleRecipeClick = (recipe) => {
        // For AI-generated recipes, pass the full recipe data via state
        if (recipe.isAIGenerated) {
            navigate(`/recipes/${recipe._id}`, { state: { recipe } });
        } else {
            navigate(`/recipes/${recipe._id}`);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                {/* Header */}
                <div className="text-center mb-12">
                    <h1 className="font-display font-bold text-4xl md:text-5xl text-gray-900 mb-4">
                        What would you like to
                        <span className="block text-gradient mt-2">cook today?</span>
                    </h1>
                    <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto">
                        Choose how you'd like to search for your next delicious meal
                    </p>
                </div>

                {/* Option Cards */}
                {!selectedMode && (
                    <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto mb-12">
                        {/* Option 1: Dish Search */}
                        <button
                            onClick={() => handleModeSelect('dish')}
                            className="card p-8 hover:shadow-xl transition-all duration-300 text-left group cursor-pointer border-2 border-transparent hover:border-primary-400"
                        >
                            <div className="w-16 h-16 gradient-primary rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                            </div>
                            <h3 className="font-display font-bold text-2xl text-gray-900 mb-3">
                                I want to cook something
                            </h3>
                            <p className="text-gray-600 text-lg">
                                Tell us what you feel like eating today
                            </p>
                            <div className="mt-6 flex items-center text-primary-600 font-medium group-hover:translate-x-2 transition-transform">
                                Get Started
                                <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                            </div>
                        </button>

                        {/* Option 2: Ingredient Search */}
                        <button
                            onClick={() => handleModeSelect('ingredient')}
                            className="card p-8 hover:shadow-xl transition-all duration-300 text-left group cursor-pointer border-2 border-transparent hover:border-primary-400"
                        >
                            <div className="w-16 h-16 gradient-primary rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                                </svg>
                            </div>
                            <h3 className="font-display font-bold text-2xl text-gray-900 mb-3">
                                I already have ingredients
                            </h3>
                            <p className="text-gray-600 text-lg">
                                Use what's already in your fridge
                            </p>
                            <div className="mt-6 flex items-center text-primary-600 font-medium group-hover:translate-x-2 transition-transform">
                                Get Started
                                <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                            </div>
                        </button>
                    </div>
                )}

                {/* Search Input Section */}
                {selectedMode && (
                    <div className="max-w-3xl mx-auto mb-12">
                        {/* Back Button */}
                        <button
                            onClick={() => handleModeSelect(null)}
                            className="flex items-center text-gray-600 hover:text-gray-900 mb-6 transition-colors"
                        >
                            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                            </svg>
                            Change search mode
                        </button>

                        {/* Search Card */}
                        <div className="card p-8 shadow-lg">
                            <h2 className="font-display font-bold text-2xl text-gray-900 mb-2">
                                {selectedMode === 'dish' ? 'What do you feel like eating today?' : 'Ingredients I already have'}
                            </h2>
                            <p className="text-gray-600 mb-6">
                                {selectedMode === 'dish'
                                    ? 'Describe the dish or cuisine you\'re craving'
                                    : 'List the ingredients you want to use'}
                            </p>

                            <form onSubmit={handleSearch} className="relative">
                                <div className="relative">
                                    <input
                                        type="text"
                                        value={query}
                                        onChange={(e) => setQuery(e.target.value)}
                                        placeholder={selectedMode === 'dish'
                                            ? 'e.g. Pasta, Paneer Butter Masala...'
                                            : 'e.g. Potato, Tomato, Onion...'}
                                        className="input pl-12 pr-4 py-4 text-lg shadow-sm"
                                        autoFocus
                                    />
                                    <div className="absolute left-4 top-1/2 -translate-y-1/2">
                                        <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                    </div>
                                    <button
                                        type="submit"
                                        disabled={!query.trim() || loading}
                                        className="absolute right-2 top-1/2 -translate-y-1/2 btn btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        {selectedMode === 'dish' ? 'Search' : 'Find Recipes'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

                {/* Results Section */}
                {selectedMode && hasSearched && (
                    <div className="max-w-7xl mx-auto">
                        {loading ? (
                            <div className="flex justify-center py-12">
                                <LoadingSpinner size="lg" text="Finding perfect recipes for you..." />
                            </div>
                        ) : recipes.length > 0 ? (
                            <>
                                <div className="flex items-center justify-between mb-6">
                                    <h3 className="font-display font-bold text-2xl text-gray-900">
                                        Found <span className="text-primary-600">{recipes.length}</span> recipes for you
                                    </h3>
                                </div>
                                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                    {recipes.map(recipe => (
                                        <div key={recipe._id} onClick={() => handleRecipeClick(recipe)}>
                                            <RecipeCard recipe={recipe} />
                                        </div>
                                    ))}
                                </div>
                            </>
                        ) : (
                            <div className="text-center py-12 card p-8 max-w-md mx-auto">
                                <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <h3 className="text-xl font-semibold text-gray-900 mb-2">No recipes found</h3>
                                <p className="text-gray-600 mb-4">Try searching with different keywords or ingredients</p>
                                <button
                                    onClick={() => {
                                        setQuery('');
                                        setHasSearched(false);
                                    }}
                                    className="btn btn-primary"
                                >
                                    Try Again
                                </button>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Home;
