import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
    const { user, isAuthenticated, logout } = useAuth();
    const navigate = useNavigate();
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center h-16">
                    {/* Logo */}
                    <Link to="/" className="flex items-center space-x-2">
                        <div className="bg-gradient-to-r from-primary-600 to-primary-400 text-white font-bold text-xl px-3 py-1 rounded-lg">
                            🍳
                        </div>
                        <span className="font-display font-bold text-xl text-gray-900">
                            Recipe<span className="text-gradient">AI</span>
                        </span>
                    </Link>

                    {/* Desktop Navigation */}
                    <div className="hidden md:flex items-center space-x-8">
                        <NavLink
                            to="/recipes"
                            className={({ isActive }) =>
                                `font-medium transition ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                            }
                        >
                            Recipes
                        </NavLink>

                        {isAuthenticated && (
                            <>
                                <NavLink
                                    to="/dashboard"
                                    className={({ isActive }) =>
                                        `font-medium transition ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                    }
                                >
                                    Dashboard
                                </NavLink>
                                <NavLink
                                    to="/meal-planner"
                                    className={({ isActive }) =>
                                        `font-medium transition ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                    }
                                >
                                    Meal Planner
                                </NavLink>
                                <NavLink
                                    to="/shopping-list"
                                    className={({ isActive }) =>
                                        `font-medium transition ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                    }
                                >
                                    Shopping List
                                </NavLink>
                            </>
                        )}
                    </div>

                    {/* Auth Buttons */}
                    <div className="hidden md:flex items-center space-x-4">
                        {isAuthenticated ? (
                            <>
                                <Link to="/profile" className="flex items-center space-x-2 text-gray-700 hover:text-primary-600 transition">
                                    <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                                        <span className="text-primary-600 font-semibold text-sm">
                                            {user?.username?.charAt(0).toUpperCase()}
                                        </span>
                                    </div>
                                    <span className="font-medium">{user?.username}</span>
                                </Link>
                                <button
                                    onClick={handleLogout}
                                    className="btn btn-secondary text-sm"
                                >
                                    Logout
                                </button>
                            </>
                        ) : (
                            <>
                                <Link to="/login" className="btn btn-secondary text-sm">
                                    Login
                                </Link>
                                <Link to="/signup" className="btn btn-primary text-sm">
                                    Sign Up
                                </Link>
                            </>
                        )}
                    </div>

                    {/* Mobile Menu Button */}
                    <button
                        onClick={() => setIsMenuOpen(!isMenuOpen)}
                        className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition"
                    >
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            {isMenuOpen ? (
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            ) : (
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                            )}
                        </svg>
                    </button>
                </div>

                {/* Mobile Menu */}
                {isMenuOpen && (
                    <div className="md:hidden py-4 border-t border-gray-200">
                        <div className="flex flex-col space-y-3">
                            <NavLink
                                to="/recipes"
                                className={({ isActive }) =>
                                    `font-medium py-2 ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                }
                                onClick={() => setIsMenuOpen(false)}
                            >
                                Recipes
                            </NavLink>

                            {isAuthenticated ? (
                                <>
                                    <NavLink
                                        to="/dashboard"
                                        className={({ isActive }) =>
                                            `font-medium py-2 ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                        }
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Dashboard
                                    </NavLink>
                                    <NavLink
                                        to="/meal-planner"
                                        className={({ isActive }) =>
                                            `font-medium py-2 ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                        }
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Meal Planner
                                    </NavLink>
                                    <NavLink
                                        to="/shopping-list"
                                        className={({ isActive }) =>
                                            `font-medium py-2 ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                        }
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Shopping List
                                    </NavLink>
                                    <NavLink
                                        to="/profile"
                                        className={({ isActive }) =>
                                            `font-medium py-2 ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                        }
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Profile
                                    </NavLink>
                                    <button
                                        onClick={() => {
                                            handleLogout();
                                            setIsMenuOpen(false);
                                        }}
                                        className="text-left text-gray-700 hover:text-primary-600 font-medium py-2"
                                    >
                                        Logout
                                    </button>
                                </>
                            ) : (
                                <>
                                    <NavLink
                                        to="/login"
                                        className={({ isActive }) =>
                                            `font-medium py-2 ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                        }
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Login
                                    </NavLink>
                                    <NavLink
                                        to="/signup"
                                        className={({ isActive }) =>
                                            `font-medium py-2 ${isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600'}`
                                        }
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Sign Up
                                    </NavLink>
                                </>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </nav>
    );
};

export default Navbar;
